---
id: power_flower
lookup: neepmeat:power_flower_seeds, neepmeat:power_flower_growth, neepmeat:power_flower_controller, neepmeat:power_flower_fluid_port
---

# 能量花

能量花能使用阳光和重组食物制造瞬变浆液。

## 使用方法

能量花种子可种在任意一种泥土类方块中，成熟后会长成庞大的增生体。增生体上方与空气接触、下方有至少一个增生体方块时，它会特化为光合器官，并持续产出10eJ/t。其他情况下，增生体会加快食物消化与代谢的速率。

水是能量花光合作用的必需品，须向能量花流体口供应水。

## 食物

每个非光合器官（完整方块）每刻会消耗1滴食物。总消耗速率和总产能速率受完整方块的数量影响。

- 肉浆：每消耗1滴产出3eJ/t
- 动物饲料：每消耗1滴产出4eJ/t
- 重组食物：每消耗1滴产出(1 + ceil(饥饿值)) eJ/t
