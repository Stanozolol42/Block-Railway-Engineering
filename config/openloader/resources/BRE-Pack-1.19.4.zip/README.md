# BRE Assets Pack

Copyright © 2026 Stanozolol42, オニオン

未特殊声明，整合包适用 [CC BY-NC-SA 4.0](https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode.txt) 协议。

对于 Block Railway Engineering 整合包标识性图案，保留所有权利（All Rights Reserved）。